package com.proyectoDesarrollo.Entities;

public enum Enum_RoleName {
    ADMIN,
    OPERARIO
}
